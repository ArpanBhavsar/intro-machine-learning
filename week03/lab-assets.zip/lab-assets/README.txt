Week 3 Lab - EarlyCheck v0.3 (Introduction to Machine Learning, Focus College, Fall 2026)

1. Keep this lab-assets/ folder next to your notebook (in Colab: upload the zip, then run  !unzip -q week3-lab-assets-student.zip ).
2. The data is lab-assets/cdc_diabetes.csv: 253,680 CDC BRFSS 2015 survey answers (UCI #891), label Diabetes_binary.
3. lab-assets/starter/ holds the starter code for every part (TODOs). Instructions and solutions are in week3-lab.html.
EarlyCheck is a learning exercise on public survey data, not medical advice.
