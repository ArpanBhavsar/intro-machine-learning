# Part 5 — Stratified 5-fold CV and a validation curve for k
# 5.1 Cross-validation and the validation curve
# See week3-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.model_selection import StratifiedKFold, cross_validate, validation_curve
import matplotlib.pyplot as plt

cv = ...   # TODO: StratifiedKFold(5, shuffle=True, random_state=42)
# TODO: for the first two folds print len(train), positive rate, len(validation), positive rate
s = ...    # TODO: cross_validate(lr, X_train, y_train, cv=cv, scoring=["recall", "f1", "roc_auc"])
ks = [1, 3, 5, 9, 15, 25, 35, 51]
# TODO: tr_s, va_s = validation_curve(make_pipeline(StandardScaler(), KNeighborsClassifier()), X_train, y_train,
#            param_name="kneighborsclassifier__n_neighbors", param_range=ks, cv=cv, scoring="roc_auc")
# TODO: print and plot tr_s.mean(1) and va_s.mean(1) against ks
