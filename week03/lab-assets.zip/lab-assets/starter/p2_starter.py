# Part 2 — Logistic regression in a Pipeline with scaling
# 2.1 Fit and read the model
# See week3-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression

lr = ...                                  # TODO: scaler + LogisticRegression(max_iter=1000)
# TODO: lr.fit(X_train, y_train)
coef = pd.Series(lr[-1].coef_[0], index=X_train.columns).sort_values()
# TODO: intercept, coef.tail(4), coef.head(2)
# TODO: np.exp(coef["BMI"]) and X_train["BMI"].std(ddof=0)
p_lr = ...                                # TODO: lr.predict_proba(X_test)[:, 1]
# TODO: first 5 probabilities, predictions, true labels; lr.score(X_test, y_test)
