# Part 3 — Math check: distance by hand, then kNN
# 3.1 Math check: distances and a hand-made vote
# See week3-lab.html for instructions. Run the parts in order in one notebook.

Q = np.array([2, 3]); P = np.array([[5, 7], [1, 1], [4, 3]])
diff = P - Q
eu = ...   # TODO: sqrt of the sum of squared differences per row
ma = ...   # TODO: sum of absolute differences per row
# TODO: compare with sklearn.metrics.pairwise
sc = StandardScaler().fit(X_train)
A, q = sc.transform(X_train), sc.transform(X_test.iloc[[0]])[0]
d = ...    # TODO: distance from q to every row of A
near = ... # TODO: indices of the 15 smallest distances (np.argsort)
# TODO: labels of those 15 neighbours and their share positive
