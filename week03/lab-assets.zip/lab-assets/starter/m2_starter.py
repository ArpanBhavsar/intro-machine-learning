# Part 2 — Logistic regression in a Pipeline with scaling
# 2.2 Math check: predict_proba is sigmoid(X·w + b), and one gradient step
# See week3-lab.html for instructions. Run the parts in order in one notebook.

Xs_test = lr[0].transform(X_test)
z_hand = ...   # TODO: Xs_test @ coef_ + intercept_
p_hand = ...   # TODO: sigmoid
# TODO: np.allclose(p_hand, p_lr)
x3 = np.array([-1.0, 0.0, 2.0]); y3 = np.array([0, 1, 1])
L = lambda w, b: ...   # TODO: log loss of sigmoid(w*x3 + b)
dw = ...; db = ...     # TODO: mean((p - y) x), mean(p - y) at w = b = 0
# TODO: nudge check (L(1e-5, 0) - L(-1e-5, 0)) / 2e-5
# TODO: w1 = 0 - 0.5*dw, b1 = 0 - 0.5*db and the loss before and after
