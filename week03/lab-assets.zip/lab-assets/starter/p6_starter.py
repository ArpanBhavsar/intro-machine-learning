# Part 6 — Choose a threshold for a recall target
# 6.1 Out-of-fold threshold table and a recall target of 0.80
# See week3-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.model_selection import cross_val_predict
p_oof = ...   # TODO: cross_val_predict(lr, X_train, y_train, cv=cv, method="predict_proba")[:, 1]
for t in [0.5, 0.3, 0.2, 0.15, 0.1]:
    pass      # TODO: recall, precision and % flagged on y_train
grid = np.round(np.arange(0.50, 0.01, -0.01), 2)
t_best = ...  # TODO: first t in grid with recall >= 0.80
# TODO: test-set recall, precision, F1 and the confusion matrix at t_best
