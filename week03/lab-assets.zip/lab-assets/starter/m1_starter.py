# Part 1 — Math check: sigmoid, odds and log loss by hand
# 1.1 Sigmoid, odds and log loss
# See week3-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.metrics import log_loss
from scipy.special import expit

z = ...                 # TODO: 1.2*HighBP + 0.9*BMI_z - 2.0
p_hand = ...            # TODO: 1 / (1 + e^-z); compare with expit(z)
# TODO: odds = p/(1-p), log-odds = ln(odds)
y4 = np.array([1, 1, 0, 0]); p4 = np.array([0.9, 0.6, 0.2, 0.95])
each = ...              # TODO: -(y ln p + (1-y) ln(1-p))
# TODO: each.mean() vs log_loss(y4, p4)
base = y_train.mean()
# TODO: baseline log loss on y_test, by hand and with log_loss
