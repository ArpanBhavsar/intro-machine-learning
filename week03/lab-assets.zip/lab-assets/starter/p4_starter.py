# Part 4 — Confusion matrix, precision, recall, F1 and ROC-AUC
# 4.1 The comparison table
# See week3-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.dummy import DummyClassifier
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, f1_score

dummy = ...   # TODO
models = {"Dummy": dummy, "LogReg": lr, "kNN k=15": knn}
rows = []
for name, m in models.items():
    prob = ...; pred = ...                       # TODO: probabilities and 0.5 threshold
    tn, fp, fn, tp = confusion_matrix(y_test, pred).ravel()
    # TODO: append [name, accuracy, precision (zero_division=0), recall, F1, ROC-AUC, tn, fp, fn, tp]
res = ...     # TODO: DataFrame indexed by model
