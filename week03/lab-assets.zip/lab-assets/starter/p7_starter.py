# Part 7 (stretch) — class_weight="balanced"
# 7.1 Balanced logistic regression
# See week3-lab.html for instructions. Run the parts in order in one notebook.

bal = ...   # TODO: scaler + LogisticRegression(max_iter=1000, class_weight="balanced"), fitted
pb = ...    # TODO: test probabilities; pred = pb >= 0.5
# TODO: accuracy, precision, recall, F1, AUC and TP/FP/FN/TN
# TODO: cross_validate(bal, ..., scoring=["recall", "roc_auc"]) means
# TODO: weights = len(y_train) / (2 * np.bincount(y_train))
