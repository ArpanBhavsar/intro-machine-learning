# Part 4 — Confusion matrix, precision, recall, F1 and ROC-AUC
# 4.2 Math check: the metrics and AUC by hand
# See week3-lab.html for instructions. Run the parts in order in one notebook.

tn, fp, fn, tp = res.loc["LogReg", ["TN", "FP", "FN", "TP"]].astype(int)
prec = ...; rec = ...; f1 = ...   # TODO
# TODO: compare with res.loc["LogReg", ["precision", "recall", "F1"]]
pos, neg = p_lr[y_test.to_numpy() == 1], p_lr[y_test.to_numpy() == 0]
wins = ...    # TODO: (pos[:, None] > neg[None, :]).sum() + 0.5 * ties
# TODO: wins / (len(pos) * len(neg)) vs roc_auc_score(y_test, p_lr)
