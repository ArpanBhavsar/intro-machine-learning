# Part 0 — Set up Colab and draw the stratified sample
# 0.1 Load, sample and split
# See week3-lab.html for instructions. Run the parts in order in one notebook.

import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split

df = pd.read_csv("lab-assets/cdc_diabetes.csv")
label = "Diabetes_binary"
y_all = ...          # TODO: the label column
X_all = ...          # TODO: drop ID and the label -> 21 features
# TODO: X, _, y, _ = train_test_split(..., train_size=20000, stratify=y_all, random_state=42)
# TODO: X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=42)
# TODO: print shapes, positive rates (sample/train/test) and test positives
