# Part 3 — Math check: distance by hand, then kNN
# 3.2 kNN in a Pipeline, scaled vs unscaled
# See week3-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import recall_score, roc_auc_score

knn = ...   # TODO: scaled kNN with k = 15, fitted on the training rows
# TODO: knn.predict_proba(X_test.iloc[[0]]) and knn[-1].kneighbors(...) vs near
raw = ...   # TODO: KNeighborsClassifier(n_neighbors=15) without scaling
# TODO: for both: accuracy, recall at 0.5, ROC-AUC on the test set
# TODO: np.ptp of BMI, Age, HighBP in X_train
