# Part 8 — Midterm rehearsal: tasks B5 and B6 on an unseen dataset  (Rehearsal (start in class, finish at home, timed))
# 8.1 B5: k-means with a justified k and a 2-D PCA plot; B6: fix the bug
# See week5-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.datasets import load_wine
wine = load_wine(as_frame=True); Xw, yw = wine.data, wine.target   # yw hidden until the end
Ws = ...   # TODO: StandardScaler().fit_transform(Xw)
# TODO B5: loop k = 2..6 (inertia, silhouette), choose k, KMeans, PCA(2), scatter, savefig("lab-assets/wine_pca.png")

# B6: this cell has a hidden bug. Find it, fix it, explain it.
bad = KMeans(n_clusters=3, n_init=10, random_state=42).fit(Xw)
# TODO: compare adjusted_rand_score(yw, ...) for the scaled and the buggy version
