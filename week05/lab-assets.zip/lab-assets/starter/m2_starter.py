# Part 2 — Scale, then choose k with the elbow and silhouette  (Do together after Section 1)
# 2.2 Math check 2: one silhouette by hand
# See week5-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.metrics import silhouette_samples
lab2 = np.array([0, 0, 0, 1, 1]); i = 0
a = ...   # TODO: mean distance to the OTHER members of its own cluster (divide by count - 1)
b = ...   # TODO: mean distance to the members of the other cluster
s = ...   # TODO: (b - a) / max(a, b)
# TODO: compare with silhouette_samples(P, lab2)[0]; print silhouette_score(P, lab2)
