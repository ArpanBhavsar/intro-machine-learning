# Part 5 — PCA map of EarlyCheck  (Do together after Section 2)
# 5.1 Ratios, loadings, scree and scatter
# See week5-lab.html for instructions. Run the parts in order in one notebook.

pca = ...   # TODO: PCA().fit(Hs)
evr = ...   # TODO: pca.explained_variance_ratio_
# TODO: print evr, evr.cumsum(), int(np.argmax(evr.cumsum() >= 0.90)) + 1
load = ...  # TODO: pd.DataFrame(pca.components_[:2].T, index=health, columns=["PC1", "PC2"]).round(2)
Z2 = ...    # TODO: pca.transform(Hs)[:, :2]
# TODO: scree bars + cumulative line; scatter of Z2 coloured by y_train; fig.savefig("lab-assets/pca_scatter.png", dpi=100)
# TODO: mean PC1 for y_train == 0 and == 1
