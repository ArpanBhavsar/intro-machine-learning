# Part 4 — PCA from scratch with SVD (Code S7)  (Do together after Section 2)
# 4.2 Math check 3: standardise, covariance, SVD, ratio, projection
# See week5-lab.html for instructions. Run the parts in order in one notebook.

T = np.array([[2, 1], [4, 3], [6, 4], [8, 8]], dtype=float)
mu = ...; sd = ...   # TODO: column means and population sds (T.std(axis=0))
Z = ...              # TODO: (T - mu) / sd
cov = ...            # TODO: Z.T @ Z / len(Z)
U2, S2, Vt2 = ...    # TODO: np.linalg.svd(Z, full_matrices=False)
evr = ...            # TODO: S2**2 / (S2**2).sum()
scores = ...         # TODO: Z @ Vt2[0]
# TODO: compare evr with PCA(n_components=2).fit(Z).explained_variance_ratio_
