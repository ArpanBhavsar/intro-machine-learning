# Part 2 — Scale, then choose k with the elbow and silhouette  (Do together after Section 1)
# 2.1 Unscaled vs scaled, elbow and silhouette plots
# See week5-lab.html for instructions. Run the parts in order in one notebook.

import matplotlib.pyplot as plt
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score
raw_km = ...    # TODO: KMeans(n_clusters=4, n_init=10, random_state=42).fit(H)
# TODO: print raw_km.cluster_centers_[:, [0, 8]]  (BMI, PhysHlth)
scaler = ...    # TODO: StandardScaler().fit(H)
Hs = ...        # TODO: scaler.transform(H)
ks, inert, sil = range(2, 9), [], []
for k in ks:
    pass        # TODO: fit KMeans on Hs, append inertia_ and the silhouette
# TODO: two subplots (elbow, silhouette), fig.savefig("lab-assets/elbow_silhouette.png", dpi=100)
