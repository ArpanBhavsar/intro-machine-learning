# Part 7 — EarlyCheck v0.5: do clusters or PCA help the Week 4 champion?  (Do together after Section 3)
# 7.1 Five pipelines, the same five folds
# See week5-lab.html for instructions. Run the parts in order in one notebook.

import time
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import make_pipeline, make_union
from sklearn.preprocessing import FunctionTransformer
from sklearn.compose import ColumnTransformer
from sklearn.linear_model import LogisticRegression
from sklearn.svm import SVC
from sklearn.model_selection import cross_val_score

class ClusterOneHot(BaseEstimator, TransformerMixin):
    def __init__(self, k=4): self.k = k
    def fit(self, X, y=None): ...       # TODO: self.km_ = KMeans(...).fit(X); return self
    def transform(self, X): ...         # TODO: np.eye(self.k)[self.km_.predict(X)]

idx = [list(X_train.columns).index(c) for c in health]
clus = ColumnTransformer([("c", ClusterOneHot(4), idx)])
champ = lambda: SVC(kernel="rbf", C=10, gamma=0.001, class_weight="balanced")
variants = {}   # TODO: the five pipelines
# TODO: for each, cross_val_score(m, X_train, y_train, cv=cv, scoring="roc_auc", n_jobs=-1); print mean ± std
