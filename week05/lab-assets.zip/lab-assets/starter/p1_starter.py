# Part 1 — k-means from scratch (Code S6) and the bad-start trap  (Do together after Section 1)
# 1.1 Code S6, inertia per iteration, five seeds
# See week5-lab.html for instructions. Run the parts in order in one notebook.

# --- Code S6 from the course guide: k-means from scratch (S1 created rng = np.random.default_rng(0))
rng = np.random.default_rng(0)
pts = np.vstack([rng.normal(c, 0.5, (50, 2)) for c in [(0, 0), (5, 5), (0, 5)]])
k = 3; centroids = pts[rng.choice(len(pts), k, replace=False)]
for it in range(10):
    labels = np.argmin(((pts[:, None] - centroids) ** 2).sum(axis=2), axis=1)   # assign
    centroids = np.array([pts[labels == j].mean(axis=0) for j in range(k)])     # update
print("S6 centroids", np.round(centroids[np.argsort(centroids[:, 0] + centroids[:, 1] * 10)], 1).tolist())

def kmeans(P, k, seed=0, iters=20, verbose=True):
    r = np.random.default_rng(seed)
    C = P[r.choice(len(P), k, replace=False)]
    for it in range(iters):
        d2 = ...        # TODO: squared distance of every point to every centroid
        lab = ...       # TODO: nearest centroid
        inertia = ...   # TODO: sum of each point's squared distance to its own centroid
        newC = ...      # TODO: mean of the members of each cluster
        # TODO: print inertia if verbose; stop if np.allclose(newC, C); C = newC
    return C, lab, inertia
# TODO: run kmeans(pts, 3); compare with sklearn KMeans; try seeds 1..5
