# Part 9 (stretch) — When k-means is the wrong tool: two moons  (Stretch goal (at home))
# 9.1 Four algorithms, one ARI table
# See week5-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.datasets import make_moons
from sklearn.cluster import DBSCAN, AgglomerativeClustering
Xm, ym = make_moons(n_samples=300, noise=0.06, random_state=0)
# TODO: for each model, lab_ = model.fit_predict(Xm); print ARI, clusters (excluding -1) and noise points
