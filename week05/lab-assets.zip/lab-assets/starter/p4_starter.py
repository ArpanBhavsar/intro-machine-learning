# Part 4 — PCA from scratch with SVD (Code S7)  (Do together after Section 2)
# 4.1 Code S7 and scikit-learn's PCA
# See week5-lab.html for instructions. Run the parts in order in one notebook.

rng = np.random.default_rng(0)
data = rng.normal(0, 1, (200, 3)); data[:, 2] = 2 * data[:, 0] + 0.1 * rng.normal(0, 1, 200)
centered = data - data.mean(axis=0)
U, S, Vt = np.linalg.svd(centered, full_matrices=False)
explained = S**2 / (S**2).sum()
projected = centered @ Vt[:2].T                       # 3D -> 2D
print("S7 explained variance", np.round(explained, 3), projected.shape)
# then:
# TODO: print("PC1 direction:", Vt[0].round(3))
from sklearn.decomposition import PCA
# TODO: p = PCA(n_components=3).fit(data); print(p.explained_variance_ratio_.round(3))
