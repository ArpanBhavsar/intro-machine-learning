# Part 0 — Load EarlyCheck and pick the health features  (Do together after Section 1)
# 0.1 Sample, split and the clustering matrix H
# See week5-lab.html for instructions. Run the parts in order in one notebook.

import numpy as np, pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold

df = pd.read_csv("lab-assets/cdc_diabetes.csv")
y_all = ...    # TODO: the Diabetes_binary column
X_all = ...    # TODO: drop ID and Diabetes_binary -> 21 features
# TODO: X, _, y, _ = train_test_split(X_all, y_all, train_size=20000, stratify=y_all, random_state=42)
# TODO: X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=42)
cv = ...       # TODO: StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
health = ["BMI", "HighBP", "HighChol", "PhysActivity", "Fruits", "Veggies", "Smoker", "GenHlth", "PhysHlth", "DiffWalk"]
H = ...        # TODO: X_train[health]
# TODO: print shapes and H.describe().loc[["mean", "std", "min", "max"]]
