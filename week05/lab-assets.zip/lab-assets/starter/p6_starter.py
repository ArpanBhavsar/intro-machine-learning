# Part 6 — Evaluate clusters: ARI and silhouette  (Do together after Section 3)
# 6.1 Blobs, relabelling, random labels, EarlyCheck
# See week5-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.metrics import adjusted_rand_score
from sklearn.datasets import make_blobs
Xb, yb = make_blobs(n_samples=300, centers=3, cluster_std=0.8, random_state=7)
lb = ...   # TODO: KMeans(n_clusters=3, n_init=10, random_state=0).fit_predict(Xb)
# TODO: ARI and silhouette on the blobs
# TODO: adjusted_rand_score([0, 0, 1, 1], [1, 1, 0, 0]); ARI of np.random.default_rng(0).integers(0, 3, 300)
# TODO: ARI(y_train, km4.labels_) and pd.crosstab(km4.labels_, y_train.values)
