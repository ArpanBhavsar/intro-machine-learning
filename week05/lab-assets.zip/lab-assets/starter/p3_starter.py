# Part 3 — Fit k = 4 and read the health profiles  (Do together after Section 1)
# 3.1 The profile table
# See week5-lab.html for instructions. Run the parts in order in one notebook.

K = 4
km4 = ...    # TODO: KMeans(n_clusters=K, n_init=10, random_state=42).fit(Hs)
prof = ...   # TODO: H.assign(cluster=km4.labels_, diabetes=y_train.values).groupby("cluster").mean().round(2)
# TODO: prof.insert(0, "size", np.bincount(km4.labels_)); print(prof); print the overall diabetes rate
