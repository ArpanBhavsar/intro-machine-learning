# Part 1 — k-means from scratch (Code S6) and the bad-start trap  (Do together after Section 1)
# 1.2 Math check 1: distance, centroid and inertia by hand
# See week5-lab.html for instructions. Run the parts in order in one notebook.

P = np.array([[1, 1], [2, 1], [1, 2], [6, 5], [7, 6]], dtype=float)
C0 = np.array([[1, 1], [6, 5]], dtype=float)
d = ...      # TODO: np.sqrt(((P[:, None] - C0) ** 2).sum(axis=2))
lab = ...    # TODO: d.argmin(axis=1)
C1 = ...     # TODO: mean of each cluster
wcss = ...   # TODO: ((P - C1[lab]) ** 2).sum()
# TODO: KMeans(n_clusters=2, init=C0, n_init=1).fit(P).inertia_ and np.isclose
