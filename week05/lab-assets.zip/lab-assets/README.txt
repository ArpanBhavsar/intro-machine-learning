Week 5 Lab - EarlyCheck v0.5: health profiles with k-means and a PCA map (Introduction to Machine Learning, Focus College, Fall 2026)

1. Keep this lab-assets/ folder next to your notebook (in Colab: upload the zip, then run  !unzip -o week5-lab-assets-student.zip ).
2. lab-assets/cdc_diabetes.csv: 253,680 CDC BRFSS 2015 survey answers (UCI #891), label Diabetes_binary (used only to describe clusters).
3. lab-assets/starter/ holds starter code for every task (TODOs): p0..p9 and the Math checks m1..m3. Instructions are in week5-lab.html.
4. The plots you make are saved into lab-assets/ (elbow_silhouette.png, pca_scatter.png, wine_pca.png). Wine, blobs and moons are built into scikit-learn.
EarlyCheck is a learning exercise on public survey data, not medical advice.
