Week 5 code-along data (Introduction to Machine Learning, Focus College, Fall 2026)

Mall_Customers.csv  200 rows. The public "Mall Customer Segmentation" teaching dataset (Kaggle, also used in the
                    Machine Learning A-Z course). Real public copy, not synthesized. Only change: the column header
                    "Genre" in the original file is renamed to "Gender". Columns: CustomerID, Gender, Age,
                    Annual Income (k$), Spending Score (1-100).
penguins.csv        344 rows. Palmer penguins (Gorman, Williams & Fraser 2014; palmerpenguins, CC0), saved from
                    seaborn.load_dataset("penguins") so no internet is needed. 2 rows lack measurements -> 342 used.
cdc_diabetes.csv    253,680 rows. CDC Diabetes Health Indicators, BRFSS 2015 (UCI #891); the same file as
                    ../lab-assets/cdc_diabetes.csv used in Weeks 2-5. Learning exercise only, not medical advice.
Wine and two-moons data are built into scikit-learn (load_wine, make_moons).
