Week 5 Code-Along: Finding Hidden Groups with Clustering and PCA
Introduction to Machine Learning · Focus College · Fall 2026 · Instructor: Arpan Bhavsar

Files
  week5-codealong.ipynb             complete code, no outputs: the copy to live-code from, cell by cell
  week5-codealong-student.ipynb     starter: key lines blanked as "... # TODO: hint"; answers behind "Check yourself" drop-downs
  week5-codealong-instructor.ipynb  solutions + the real outputs and plots from a top-to-bottom run
  week5-codealong.html              interactive companion that mirrors the notebook section by section
  data/                             Mall_Customers.csv, penguins.csv, cdc_diabetes.csv (see data/README.txt)

Colab: upload the zip, run  !unzip -o week5-codealong-student.zip  in the first cell, then open the notebook.

Presenting the HTML companion
  P = present mode (one section per screen, larger type). Arrow keys move between sections; Space reveals the
  prediction answer, then the real output, then moves on.  I = show the instructor note in the midterm review.
  "Show all outputs" opens every output at once (review mode). Each code block has "Full code" / "Student starter" tabs.

Rebuild (after editing build/content.py):  python3 build/build_nb.py --execute && python3 build/build_html.py
