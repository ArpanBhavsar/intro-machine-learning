Week 4 Lab - Scam Shield and EarlyCheck v0.4 (Introduction to Machine Learning, Focus College, Fall 2026)

1. Keep this lab-assets/ folder next to your notebook (in Colab: upload the zip, then run  !unzip -o week4-lab-assets-student.zip ).
2. lab-assets/cdc_diabetes.csv: 253,680 CDC BRFSS 2015 survey answers (UCI #891), label Diabetes_binary.
3. lab-assets/sms_spam.tsv: the UCI SMS Spam Collection (#228), 5,574 messages, tab-separated label and text, no header.
4. lab-assets/starter/ holds starter code for every task (TODOs): p0..p8 and the Math checks m1..m4. Instructions are in week4-lab.html.
EarlyCheck is a learning exercise on public survey data, not medical advice.
