# Part 3 — Gini by hand, then a real decision tree  (Do together after Section 3)
# 3.1 Code S5, the ten patients, the stump and the depth loop
# See week4-lab.html for instructions. Run the parts in order in one notebook.

# --- Code S5 (course guide): Gini for one split; expected output: S5 gini_left=0.375 gini_right=0.320 weighted=0.344
def gini(labels):
    _, c = np.unique(labels, return_counts=True); p = c / c.sum()
    return 1 - (p ** 2).sum()
left, right = np.array([1,1,1,0]), np.array([0,0,0,0,1])
weighted = (len(left)*gini(left) + len(right)*gini(right)) / 9
print(f"S5 gini_left={gini(left):.3f} gini_right={gini(right):.3f} weighted={weighted:.3f}")
from sklearn.model_selection import cross_validate
from sklearn.tree import DecisionTreeClassifier, export_text

def gini(labels):
    ...   # TODO: p = np.bincount(labels, minlength=2) / len(labels); return 1 - (p ** 2).sum()
def split_gini(col, labels):
    ...   # TODO: size-weighted Gini of labels[col == 1] and labels[col == 0]
ten = pd.DataFrame({"HighBP": [1, 1, 1, 0, 1, 1, 0, 0, 0, 0], "BMI30": [1, 1, 0, 1, 1, 0, 0, 0, 0, 0],
                    "Age60": [0, 1, 1, 1, 1, 0, 1, 1, 0, 0], "sick": [1, 1, 1, 1, 0, 0, 0, 0, 0, 0]})
# TODO: parent Gini, then weighted Gini and gain for each question
stump = ...   # TODO: DecisionTreeClassifier(max_depth=1, random_state=42).fit(X_train, y_train)
f = X_train.columns[stump.tree_.feature[0]]; t = stump.tree_.threshold[0]
# TODO: print f, t, stump.tree_.impurity; fit and print a depth-2 tree with export_text
# TODO: for d in [2, 5, 10, None]: cross_validate(..., return_train_score=True); print train and CV AUC
