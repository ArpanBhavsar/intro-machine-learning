# Part 6 — Tune two models with GridSearchCV  (Do together after Section 5)
# 6.1 Forest and SVM grids
# See week4-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.model_selection import GridSearchCV
rf_grid = ...    # TODO: GridSearchCV(RandomForestClassifier(n_estimators=200, n_jobs=-1, random_state=42), {...}, cv=cv, scoring="roc_auc").fit(X_train, y_train)
svm_grid = ...   # TODO: GridSearchCV(make_pipeline(StandardScaler(), SVC(kernel="rbf", class_weight="balanced")),
                 #        {"svc__C": [...], "svc__gamma": [...]}, cv=cv, scoring="roc_auc", n_jobs=-1).fit(X_train, y_train)
# TODO: best_params_ and best_score_ for both; pivot svm_grid.cv_results_ into a C x gamma table
