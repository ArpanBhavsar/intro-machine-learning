# Part 2 — SVM on EarlyCheck: unscaled, scaled, balanced  (Do together after Section 2)
# 2.1 Three SVMs and their support vectors
# See week4-lab.html for instructions. Run the parts in order in one notebook.

import time
from sklearn.svm import SVC
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import cross_val_score

def cv_auc(model):
    ...   # TODO: time cross_val_score(model, X_train, y_train, cv=cv, scoring="roc_auc"); return mean, std, seconds
# TODO: print cv_auc for unscaled, scaled, and scaled + class_weight="balanced"
svm = ... # TODO: the balanced pipeline, fitted on X_train, y_train
# TODO: print svm[-1].n_support_
