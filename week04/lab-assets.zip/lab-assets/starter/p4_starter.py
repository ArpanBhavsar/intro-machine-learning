# Part 4 — Grow a forest and read its importances  (Do together after Section 4)
# 4.1 Forest size, OOB and two importances
# See week4-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.model_selection import cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.inspection import permutation_importance

for n in [1, 10, 100, 200]:
    pass   # TODO: CV ROC-AUC mean +/- std
rf = ...   # TODO: 200 trees, min_samples_leaf=20, oob_score=True, fitted on the training rows
# TODO: print rf.oob_score_
mdi = ...  # TODO: pd.Series(rf.feature_importances_, index=X_train.columns).sort_values(ascending=False)
perm = ... # TODO: permutation_importance(rf, X_test, y_test, scoring="roc_auc", n_repeats=10, random_state=42, n_jobs=-1)
# TODO: top 6 of each; CholCheck in both
