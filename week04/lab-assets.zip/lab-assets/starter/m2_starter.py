# Part 2 — SVM on EarlyCheck: unscaled, scaled, balanced  (Do together after Section 2)
# 2.2 Math check 2: margin width, hinge loss and C
# See week4-lab.html for instructions. Run the parts in order in one notebook.

P5 = np.array([[1, 1], [2, 1.5], [3, 3], [2.6, 2.6], [4, 3]]); y5 = np.array([-1, -1, 1, 1, 1])
for name, w, b in [("narrow", np.array([1.0, 1.0]), -4.0), ("wide", np.array([0.5, 0.5]), -2.0)]:
    f = ...       # TODO: P5 @ w + b
    hinge = ...   # TODO: np.maximum(0, 1 - y5 * f)
    width = ...   # TODO: 2 / np.linalg.norm(w)
    # TODO: print the objective 0.5 * w @ w + C * hinge.sum() for C in (0.1, 1, 10)
for C in (0.1, 10):
    pass          # TODO: SVC(kernel="linear", C=C).fit(P5, y5); print coef_, intercept_, width and n_support_.sum()
