# Part 1 — Scam Shield: Naive Bayes from scratch and in scikit-learn  (Do together after Section 1)
# 1.1 Code S4, the from-scratch filter, and two library pipelines
# See week4-lab.html for instructions. Run the parts in order in one notebook.

# --- Code S4 (course guide): the same Naive Bayes idea on six tiny messages; expected output: S4 spam ham
from collections import Counter
import math
train = [("win free cash now", "spam"), ("free prize claim now", "spam"),
         ("are we meeting for lunch", "ham"), ("see you at class tomorrow", "ham"),
         ("claim your free gift", "spam"), ("lunch tomorrow at noon", "ham")]
counts = {"spam": Counter(), "ham": Counter()}; docs = Counter()
for text, label in train:
    counts[label].update(text.split()); docs[label] += 1
vocab = set(w for c in counts.values() for w in c)
def nb_predict(text):
    scores = {}
    for label in counts:
        total = sum(counts[label].values())
        score = math.log(docs[label] / sum(docs.values()))              # prior
        for word in text.split():                                          # likelihoods (+1 smoothing)
            score += math.log((counts[label][word] + 1) / (total + len(vocab)))
        scores[label] = score
    return max(scores, key=scores.get)
print("S4", nb_predict("free cash prize"), nb_predict("lunch at class"))
import re
from collections import Counter
tokens = lambda s: re.findall(r"[a-z0-9']+", s.lower())

spam_c, ham_c = Counter(), Counter()
# TODO: for each (text, lab) in zip(s_train, l_train), update spam_c or ham_c with tokens(text)
vocab = ...; V = ...            # TODO: words seen in either class, and how many
n_spam, n_ham = ...             # TODO: total words in each class
prior_spam = ...                # TODO: share of spam in l_train
def score(text, c, n, prior):
    ...                         # TODO: log prior + sum of log((c[w] + 1) / (n + V)) for words in vocab
def predict(text):
    ...                         # TODO: 1 if the spam score beats the ham score
# TODO: accuracy, precision, recall on s_test

from sklearn.feature_extraction.text import CountVectorizer, TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import make_pipeline
from sklearn.metrics import accuracy_score, precision_score, recall_score
# TODO: both vectorizers + MultinomialNB(alpha=1.0); fit on s_train, score on s_test
# TODO: scam = Count pipeline; print predict_proba for two messages
