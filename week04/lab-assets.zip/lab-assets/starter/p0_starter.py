# Part 0 — Load EarlyCheck and the SMS collection  (Do together after Section 1)
# 0.1 Sample, split, folds and the SMS file
# See week4-lab.html for instructions. Run the parts in order in one notebook.

import csv, numpy as np, pandas as pd
from sklearn.model_selection import train_test_split, StratifiedKFold

df = pd.read_csv("lab-assets/cdc_diabetes.csv")
y_all = ...    # TODO: the Diabetes_binary column
X_all = ...    # TODO: drop ID and Diabetes_binary -> 21 features
# TODO: X, _, y, _ = train_test_split(X_all, y_all, train_size=20000, stratify=y_all, random_state=42)
# TODO: X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, stratify=y, random_state=42)
cv = ...       # TODO: StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
# TODO: print shapes and positive rates

sms = pd.read_csv("lab-assets/sms_spam.tsv", sep="\t", header=None, names=["label", "text"], quoting=csv.QUOTE_NONE)
# TODO: print len(sms) and the label counts
# TODO: s_train, s_test, l_train, l_test = train_test_split(sms["text"], (sms["label"] == "spam").astype(int),
#                                                          test_size=0.25, stratify=sms["label"], random_state=42)
