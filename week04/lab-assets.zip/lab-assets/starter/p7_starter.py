# Part 7 — Open the test set once: three finalists  (Do together after Section 5)
# 7.1 Test AUC, confusion matrices and ROC curves
# See week4-lab.html for instructions. Run the parts in order in one notebook.

import matplotlib.pyplot as plt
from sklearn.metrics import roc_auc_score, roc_curve, confusion_matrix
finalists = {"SVM (tuned)": svm_grid.best_estimator_, "Random forest (tuned)": rf_grid.best_estimator_,
             "LogReg": models["LogReg"].fit(X_train, y_train)}
fig, ax = plt.subplots(figsize=(5.5, 4.5))
for name, m in finalists.items():
    score = ...   # TODO: decision_function for the SVM, predict_proba[:, 1] otherwise
    # TODO: roc_curve, confusion_matrix(y_test, m.predict(X_test)), print AUC, TP FN FP TN, recall, precision
    # TODO: ax.plot(fpr, tpr, label=...)
# TODO: diagonal, labels, legend, fig.savefig("lab-assets/roc_top3.png", dpi=110)
