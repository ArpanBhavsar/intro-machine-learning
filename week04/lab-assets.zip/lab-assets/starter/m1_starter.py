# Part 1 — Scam Shield: Naive Bayes from scratch and in scikit-learn  (Do together after Section 1)
# 1.2 Math check 1: Bayes' theorem on real counts, and Activity 1
# See week4-lab.html for instructions. Run the parts in order in one notebook.

has = lambda w: s_train.map(lambda t: w in tokens(t))
for w in ["free", "prize", "later"]:
    a = ...; b = ...            # TODO: spam texts and ham texts containing w
    p_w_s, p_w_h = ...          # TODO: a / number of spam texts, b / number of ham texts
    # TODO: posterior = p_w_s*prior / (p_w_s*prior + p_w_h*(1 - prior))

toy = ["free prize now", "win free cash now", "claim prize now", "call me later", "see you later", "free lunch now", "call you now"]
toy_y = np.array([1, 1, 1, 0, 0, 0, 0])
# TODO: CountVectorizer on toy; word totals per class; V
# TODO: spam score = 3/7 * product of (count + 1) / (spam words + V) for free, prize, call; same for ham with 4/7
# TODO: P(spam) by hand vs MultinomialNB(alpha=1.0).fit(...).predict_proba(...)
