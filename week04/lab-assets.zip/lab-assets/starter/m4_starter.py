# Part 5 — The seven-model bake-off  (Do together after Section 5)
# 5.2 Math check 4: mean ± std by hand
# See week4-lab.html for instructions. Run the parts in order in one notebook.

f5 = fold_auc["LogReg"]
mean = ...   # TODO: f5.sum() / 5
std = ...    # TODO: np.sqrt(((f5 - mean) ** 2).sum() / 5)
# TODO: compare with f5.mean() and f5.std()
