# Part 8 (stretch) — Boosting: HistGradientBoosting and XGBoost  (Stretch goal (after Section 5, or at home))
# 8.1 Two boosters on the same folds
# See week4-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.ensemble import HistGradientBoostingClassifier
# TODO: CV ROC-AUC of HistGradientBoostingClassifier(random_state=42)
try:
    from xgboost import XGBClassifier
    pass   # TODO: CV ROC-AUC of the XGBClassifier above
except ImportError:
    print("xgboost is not installed here: pip install xgboost")
