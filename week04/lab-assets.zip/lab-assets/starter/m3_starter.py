# Part 3 — Gini by hand, then a real decision tree  (Do together after Section 3)
# 3.2 Math check 3: root Gini and entropy by hand
# See week4-lab.html for instructions. Run the parts in order in one notebook.

n0, n1 = ...; p1 = ...      # TODO: counts of y_train == 0 and == 1, and the positive share
# TODO: Gini = 1 - (p1**2 + (1-p1)**2) vs stump.tree_.impurity[0]
# TODO: entropy = -(p1 log2 p1 + (1-p1) log2 (1-p1)) vs a criterion="entropy" stump
left = ...; right = ...     # TODO: y_train where X_train[f] <= t, and > t
# TODO: gini of each child and the size-weighted average
