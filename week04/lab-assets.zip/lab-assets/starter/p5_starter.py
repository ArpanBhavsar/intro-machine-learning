# Part 5 — The seven-model bake-off  (Do together after Section 5)
# 5.1 Seven pipelines, one table
# See week4-lab.html for instructions. Run the parts in order in one notebook.

from sklearn.model_selection import cross_validate
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

models = {
    "Dummy": ...,            # TODO: DummyClassifier(strategy="most_frequent")
    "LogReg": ...,           # TODO: make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
    "kNN (k=51)": ...,
    "GaussianNB": ...,
    "SVM (RBF)": ...,
    "Tree (depth 5)": ...,
    "Random forest": ...,    # TODO: 200 trees, n_jobs=-1, random_state=42
}
rows, fold_auc = [], {}
for name, m in models.items():
    pass   # TODO: cross_validate(m, X_train, y_train, cv=cv, scoring=[...]); save s["test_roc_auc"]; build the row
# TODO: table = pd.DataFrame(rows, ...).set_index("model"); print(table)
