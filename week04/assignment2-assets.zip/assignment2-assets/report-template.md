# Assignment 2 — Model Bake-Off: report template (2–3 pages)
Name · Student ID · Team · Dataset

## 1. Setup (about ½ page)
- Dataset, target, positive rate, rows used (and sample size if you sampled, with why).
- Your chosen metric and why it fits the problem (who is harmed by a false negative vs a false positive?).
- Preprocessing reused from Assignment 1 (one sentence per step) and how it sits inside every pipeline.

## 2. Comparison table (stratified 5-fold CV, mean ± std)
| Model | Your metric | Accuracy | Recall | F1 | Fit time (s) |
|---|---|---|---|---|---|
| Dummy | | | | | |
| Logistic regression | | | | | |
| kNN (k = ?) | | | | | |
| Naive Bayes (which variant?) | | | | | |
| SVM | | | | | |
| Random forest | | | | | |
| Decision tree (bonus) | | | | | |

Two or three sentences: which differences are larger than one standard deviation, and which are not?

## 3. Tuning
For each tuned model: the search (grid or random), the ranges and why, the best hyperparameters, CV score before → after.

## 4. Visual evaluation (test set, opened once)
- ROC curves for your top three (one figure) and a confusion matrix for each.
- Random forest feature importance (and permutation importance if you computed it). Describe it without causal words.

## 5. Champion
Metric, evidence, trade-off, what the errors look like (who is missed? who is falsely flagged?), biggest weakness and how you would reduce it.

## 6. AI-use note and references
APA-style citation for any AI tool used and one sentence on how. Sources for any outside claim.
