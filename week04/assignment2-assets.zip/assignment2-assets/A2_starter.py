# %% [markdown]
# # Assignment 2 — Model Bake-Off (starter)
# Introduction to Machine Learning · Focus College · Fall 2026 · Instructor: Arpan Bhavsar
#
# Reuse your **Assignment 1 pipeline** on your **team's dataset**. Fill in the CONFIG cell, keep every model in the
# same pipeline, compare with stratified 5-fold CV, tune at least two models, open the test set **once** at the end.
# The defaults below run the Week 4 EarlyCheck example (`lab-assets/cdc_diabetes.csv` from the Week 4 lab zip) so you
# can check that the notebook works before switching to your own data.

# %% CONFIG — change these for your team dataset
DATA_PATH = "lab-assets/cdc_diabetes.csv"   # your team's CSV
TARGET = "Diabetes_binary"                   # your label column (binary classification)
DROP = ["ID"]                                # ID-like columns that must not be features
METRIC = "roc_auc"                           # your chosen metric (justify it in the report): roc_auc, recall, f1, average_precision ...
SAMPLE_ROWS = 20000                          # sample large data so SVM and kNN finish in Colab (None = use all rows)
SEED = 42

# %% 1. Load, (sample), split — reuse your Assignment 1 preparation here
import time, numpy as np, pandas as pd, matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, StratifiedKFold, cross_validate, GridSearchCV
from sklearn.pipeline import make_pipeline
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.impute import SimpleImputer

df = pd.read_csv(DATA_PATH)
y_all = df[TARGET]; X_all = df.drop(columns=[TARGET] + DROP)
if SAMPLE_ROWS and len(df) > SAMPLE_ROWS:
    X_all, _, y_all, _ = train_test_split(X_all, y_all, train_size=SAMPLE_ROWS, stratify=y_all, random_state=SEED)
X_train, X_test, y_train, y_test = train_test_split(X_all, y_all, test_size=0.25, stratify=y_all, random_state=SEED)
cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=SEED)       # the SAME folds for every model
print("train", X_train.shape, "test", X_test.shape, "positive rate %.4f / %.4f" % (y_train.mean(), y_test.mean()))

# Preprocessing: numeric -> impute + scale, categorical -> impute + one-hot. Replace with your A1 ColumnTransformer if you have one.
num = X_train.select_dtypes("number").columns.tolist(); cat = [c for c in X_train.columns if c not in num]
def prep():
    return ColumnTransformer([("num", make_pipeline(SimpleImputer(strategy="median"), StandardScaler()), num),
                              ("cat", make_pipeline(SimpleImputer(strategy="most_frequent"), OneHotEncoder(handle_unknown="ignore", sparse_output=False)), cat)])

# %% 2. At least six models in the same pipeline (a single tree is a bonus)
from sklearn.dummy import DummyClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier

models = {
    "Dummy":          make_pipeline(prep(), DummyClassifier(strategy="most_frequent")),
    "LogReg":         make_pipeline(prep(), LogisticRegression(max_iter=1000)),
    "kNN":            make_pipeline(prep(), KNeighborsClassifier(n_neighbors=51)),   # TODO: use the k you chose in A1/Week 3
    "GaussianNB":     make_pipeline(prep(), GaussianNB()),
    "SVM (RBF)":      make_pipeline(prep(), SVC(kernel="rbf")),
    "Random forest":  make_pipeline(prep(), RandomForestClassifier(n_estimators=200, n_jobs=-1, random_state=SEED)),
    "Tree (bonus)":   make_pipeline(prep(), DecisionTreeClassifier(max_depth=5, random_state=SEED)),
}

# %% 3. Stratified 5-fold CV: your metric + accuracy (+ recall, F1), mean ± std
scoring = list(dict.fromkeys([METRIC, "accuracy", "recall", "f1"]))
rows = []
for name, m in models.items():
    t = time.time(); s = cross_validate(m, X_train, y_train, cv=cv, scoring=scoring)
    rows.append([name] + [f"{s['test_' + k].mean():.3f} ± {s['test_' + k].std():.3f}" for k in scoring] + [round(time.time() - t, 1)])
table = pd.DataFrame(rows, columns=["model"] + scoring + ["seconds"]).set_index("model")
print(table.to_string())
table.to_csv("a2_comparison_table.csv")

# %% 4. Tune at least two models with GridSearchCV or RandomizedSearchCV (training data + CV only)
rf_grid = GridSearchCV(models["Random forest"], {"randomforestclassifier__max_depth": [8, None],
                                                 "randomforestclassifier__min_samples_leaf": [1, 20]},
                       cv=cv, scoring=METRIC, n_jobs=-1).fit(X_train, y_train)
svm_grid = GridSearchCV(make_pipeline(prep(), SVC(kernel="rbf", class_weight="balanced")),
                        {"svc__C": [1, 10], "svc__gamma": [0.001, 0.01]}, cv=cv, scoring=METRIC, n_jobs=-1).fit(X_train, y_train)
for n, g in [("Random forest", rf_grid), ("SVM balanced", svm_grid)]:
    print(n, "best", g.best_params_, "CV %s %.4f" % (METRIC, g.best_score_))
# TODO: widen the grids sensibly for your data and explain your choices in the report

# %% 5. Open the test set ONCE: confusion matrices and ROC curves for your top three, RF importances
from sklearn.metrics import roc_curve, roc_auc_score, ConfusionMatrixDisplay
from sklearn.inspection import permutation_importance
top3 = {"SVM (tuned)": svm_grid.best_estimator_, "Random forest (tuned)": rf_grid.best_estimator_,
        "LogReg": models["LogReg"].fit(X_train, y_train)}           # TODO: your own top three by CV
fig, axes = plt.subplots(1, 4, figsize=(18, 4))
for ax, (name, m) in zip(axes[1:], top3.items()):
    ConfusionMatrixDisplay.from_estimator(m, X_test, y_test, ax=ax, colorbar=False); ax.set_title(name)
for name, m in top3.items():
    sc = m.decision_function(X_test) if hasattr(m, "decision_function") and not hasattr(m, "predict_proba") else m.predict_proba(X_test)[:, 1]
    fpr, tpr, _ = roc_curve(y_test, sc); axes[0].plot(fpr, tpr, label="%s (AUC %.3f)" % (name, roc_auc_score(y_test, sc)))
axes[0].plot([0, 1], [0, 1], "k--", lw=1); axes[0].legend(fontsize=8); axes[0].set_title("ROC, test set (opened once)")
fig.tight_layout(); fig.savefig("a2_top3.png", dpi=110)

rf = rf_grid.best_estimator_; names = rf[0].get_feature_names_out()
mdi = pd.Series(rf[-1].feature_importances_, index=names).sort_values(ascending=False)
print("Random forest impurity importance (top 8):\n" + mdi.head(8).round(4).to_string())
# TODO (recommended): permutation_importance on a validation split, and explain any disagreement — without causal words

# %% 6. Champion
# TODO: in the report, name your champion and justify it: metric, evidence (CV mean ± std, test result), trade-offs,
# what its errors look like, its biggest weakness and how you would reduce it (threshold, class weights, more data).
