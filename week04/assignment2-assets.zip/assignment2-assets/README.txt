Assignment 2 - Model Bake-Off (Introduction to Machine Learning, Focus College, Fall 2026)
A2_starter.ipynb / A2_starter.py : a runnable skeleton. Its CONFIG defaults run the Week 4 EarlyCheck example
                                   (needs lab-assets/cdc_diabetes.csv from week4-lab-assets-student.zip next to it).
                                   Change DATA_PATH, TARGET, DROP and METRIC for your team dataset.
report-template.md               : the 2-3 page report structure, with the comparison-table layout.
submission-checklist.md          : check every box before you submit.
Due Saturday, October 31, 2026, before midnight PT.
